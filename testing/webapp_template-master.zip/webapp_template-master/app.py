from flask_socketio import SocketIO, emit
from flask_cors import CORS
from flask import Flask, render_template
import json


app = Flask(__name__)
CORS(app)
socketio = SocketIO(app)


@app.route('/')
def site():
    return render_template('Home.html')


@socketio.on('AddE', namespace='/events')
def operation(message):
    Dat1 = json.loads(json.dumps(message))
    V1 = float(Dat1["V1"])
    V2 = float(Dat1["V2"])
    print('Value 1: ', V1, " Value 2 : ", V2)
    result = V1 + V2
    print('Result (V1+V2): ', result)
    socketio.emit('result', {'result': result}, namespace='/events')


if __name__ == '__main__':
    socketio.run(app)
