# WebApp template

Interactive WebApp template using python3 (Flask + SocketIo)

To run:

* Use the venv provided or check and install the required dependencies in your local environment from ```Dependencies.txt```
* Execute ```app.py```
* Access localhost from your web browser http://127.0.0.1:5000/